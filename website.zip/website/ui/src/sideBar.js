import React,{Component} from 'react';
import './App.css';

export default class SideBar extends Component{

    render(){
        return(<div>
                <div class="w3-sidebar w3-light-grey w3-bar-block" style={{width:'6%',marginTop:'50px'}}>
  
  <a href="#" className="w3-bar-item w3-button"><i className="fa fa-bar-chart"></i></a>
  <a href="#" className="w3-bar-item w3-button" ><i className="fa fa-arrow-right "></i></a>
  <a href="#" className="w3-bar-item w3-button"><i className="fa fa-trash-o"></i></a>
  <a href="#" className="w3-bar-item w3-button"><i className="fa fa-info"></i></a>
  <a href="#" className="w3-bar-item w3-button"><i className="fa fa-clipboard"></i></a>
  <a href="#" className="w3-bar-item w3-button"><i className="fa fa-flag"></i></a>
  <a href="#" className="w3-bar-item w3-button"><i className="fa fa-tag"></i></a>
  <a href="#" className="w3-bar-item w3-button"><i className="fa fa-shopping-cart"></i></a>
  <a href="#" className="w3-bar-item w3-button"><i className="fa fa-users"></i></a>
  <hr style={{backgroundColor:'lightgray',height:'1px'}}/>
  <b><a href="#" className="w3-bar-item w3-button" >></a></b>
</div>
        </div>);
    }
}